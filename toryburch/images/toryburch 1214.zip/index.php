<!DOCTYPE html>
<html lang="en">
 <head>
<meta charset="utf-8" /> 
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>최진아 포트폴리오</title>
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
<meta name="description" content="웹포트폴리오 최진아">
<meta name="keywords"    content="웹 퍼블리셔, HTML5, CSS3, jQuery ,웹 디자인">
<meta name="author"      content="최진아 ">
<link rel="shortcut icon" href="img/favicon_1.ico">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">  
<link rel="stylesheet" href="fa/css/font-awesome.min.css" />
<link rel="stylesheet" href="css/import.css" type="text/css"/>  
<!--[if lt IE 9]><script src="js/IE9.js"></script><![endif]-->     
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]--> 
</head>
   
<body> 
<div id="sikpNav" class="hide">
	<p><a href="#contents">본문바로가기</a></p>
	<p><a href="#gnb">메뉴바로가기</a></p>	
</div>

<div class="header-wrap">
<header id="header">
	<h1><a href="#"><img src="images/logo.png" alt="토리버치 로고" /> </a></h1>
<dl class="cf"> 
	<dt class="hide">top-menu</dt>
	<dd><a href="#">SEARCH </a></dd>
	<dd><a href="#">LOGIN  </a></dd>
	<dd><a href="#">ABOUT TORY</a></dd>
</dl>
<nav id="nav">
	<ul id="gnb" class="cf">
		<li><a href="#">GIFT GUIDE</a>
			<ul>
				<li><a href="#">OUR MUST-HAVES</a></li>
				<li><a href="#">THE CLASSICS</a></li>
				<li><a href="#">GIFTS UNDER 30만원</a></li>
			</ul>
		</li>
		<li><a href="#">CLOTHING </a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">스웨터</a></li>
				<li><a href="#">카디건</a></li>
				<li><a href="#">재킷/아우터</a></li>
				<li><a href="#">스커트</a></li>
				<li><a href="#">팬츠</a></li>
				<li><a href="#">셔츠/블라우스</a></li>
				<li><a href="#">드레스</a></li>
				<li><a href="#">탑/티셔츠</a></li>
				<li><a href="#">스윔</a></li>
			</ul>
		</li>
		<li><a href="#">SHOES</a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">부츠/부티</a></li>
				<li><a href="#">힐/펌프스</a></li>
				<li><a href="#">발레 플랫</a></li>
				<li><a href="#">웨지</a></li>
				<li><a href="#">로퍼</a></li>
				<li><a href="#">스니커즈</a></li>
				<li><a href="#">샌들</a></li>
				<li><a href="#">플립플랍</a></li>
				<li><a href="#">에스빠드리유</a></li>
			</ul>
		</li>
		<li><a href="#">HANDBAGS</a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">사첼</a></li>
				<li><a href="#">클러치</a></li>
				<li><a href="#">크로스바디백</a></li>
				<li><a href="#">토트</a></li>
				<li><a href="#">숄더백</a></li>
				<li><a href="#">백팩</a></li>
			</ul>	
		</li>
		<li><a href="#">ACCESSORIES</a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">지갑</a></li>
				<li><a href="#">키홀더</a></li>
				<li><a href="#">스카프/모자</a></li>
				<li><a href="#">코스메틱 파우치</a></li>
				<li><a href="#">향수</a></li>
				<li><a href="#">주얼리</a></li>
				<li><a href="#">테크 액세서리</a></li>
			</ul>	
		</li>
		<li><a href="#">SALE</a>
			<ul>
				<li><a href="#">Clothing</a></li>
				<li><a href="#">Shoes</a></li>
				<li><a href="#">Handbags</a></li>
				<li><a href="#">Accessories</a></li>
			</ul>	
		</li>
	</ul>
</nav><!--////////////////////////////// 주요메뉴-->
<a href="#" class="all-open"></a>
<div id="allMenu">
	<a href="javascript:" class="close">X </a>
	<ul class="gnb">
		<li><a href="#">GIFT GUIDE</a>
			<ul>
				<li><a href="#">OUR MUST-HAVES</a></li>
				<li><a href="#">THE CLASSICS</a></li>
				<li><a href="#">GIFTS UNDER 30만원</a></li>
				<li></li>
			</ul>
		</li>
		<li><a href="#">CLOTHING </a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">스웨터</a></li>
				<li><a href="#">카디건</a></li>
				<li><a href="#">재킷/아우터</a></li>
				<li><a href="#">스커트</a></li>
				<li><a href="#">팬츠</a></li>
				<li><a href="#">셔츠/블라우스</a></li>
				<li><a href="#">드레스</a></li>
				<li><a href="#">탑/티셔츠</a></li>
				<li><a href="#">스윔</a></li>
			</ul>
		</li>
		<li><a href="#">SHOES</a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">부츠/부티</a></li>
				<li><a href="#">힐/펌프스</a></li>
				<li><a href="#">발레 플랫</a></li>
				<li><a href="#">웨지</a></li>
				<li><a href="#">로퍼</a></li>
				<li><a href="#">스니커즈</a></li>
				<li><a href="#">샌들</a></li>
				<li><a href="#">플립플랍</a></li>
				<li><a href="#">에스빠드리유</a></li>
			</ul>
		</li>
		<li><a href="#">HANDBAGS</a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">사첼</a></li>
				<li><a href="#">클러치</a></li>
				<li><a href="#">크로스바디백</a></li>
				<li><a href="#">토트</a></li>
				<li><a href="#">숄더백</a></li>
				<li><a href="#">백팩</a></li>
				<li></li>
			</ul>	
		</li>
		<li><a href="#">ACCESSORIES</a>
			<ul>
				<li><a href="#">신상품</a></li>
				<li><a href="#">지갑</a></li>
				<li><a href="#">키홀더</a></li>
				<li><a href="#">스카프/모자</a></li>
				<li><a href="#">코스메틱 파우치</a></li>
				<li><a href="#">향수</a></li>
				<li><a href="#">주얼리</a></li>
				<li><a href="#">테크 액세서리</a></li>
			</ul>	
		</li>
		<li><a href="#">SALE</a>
			<ul>
				<li><a href="#">Clothing</a></li>
				<li><a href="#">Shoes</a></li>
				<li><a href="#">Handbags</a></li>
				<li><a href="#">Accessories</a></li>
			</ul>	
		</li>
	</ul>
</div><!--////////////////////////////// all메뉴-->
</header>
</div><!--////////////////////////////// header wrap-->

<div class="visual-content-wrap">

	<section id="visual">
	<div class="v-box">
		<ul class="cf visual-img">
			<li>
				<a href="#">
				<strong>NIGHT MOVES</strong>
				<em>파티룩에 어울리는 추천 아이템</em>
				</a>
			</li>
			<li>
				<a href="#">
				<strong>THE GIFT GUIDE</strong>
				<em>머스트-해브 선물 아이템 제안</em>
				</a>
			</li>
			<li>
				<a href="#">
				<strong>THE ULTIMATE GIFT</strong>
				<em>제미나이 링크 토트</em>
				</a>
			</li>
		</ul>
		<ul class="paging cf">
			<li><a href="#">&lt;</a></li>
			<li class="on"><a href="#"></a></li>
			<li><a href="#"></a></li>
			<li><a href="#"></a></li>
			<li><a href="#">&gt;</a></li>
		</ul>
		</div>
		<div class="today-pick">
		<ul>
		<li><img src="images/todays.png" alt="오늘의 추천 아이템" /></li>
		<li><img src="images/todays3.png" alt="오늘의 추천 아이템" /></li>
		</ul>
		<div class="bg-box">
		<h3>TODAY'S PICK</h3>
		<a href="#">
		<span>373</span>
		<em>케이틀린 스트레치 부츠<br/>부드러운 블랙 카프스킨과 네오플랜 소재를 믹스한 무릎까지 오는 스타일</em>
		</a>
		</div>
		</div>
	</section>


	
	<div id="container">
		<section id="content">
			<div class="sale-timer">
			<a href="#">
			<strong>TIME SALE</strong>
			<em>2 4 : 0 0 : 0 0</em>
			</a>
			</div>
			
			<div class="new-product">
			<h3>NEW PRODUCT</h3>
			<ul>
				<li><a href="#">
					<strong>CLOTHING</strong>
					<em>자세히 보기</em>
				</a></li>
				<li><a href="#">
					<strong> SHOES</strong>
					<em>자세히 보기</em>
				</a></li>
				<li><a href="#">
					<strong>HANDBAGS</strong>
					<em>자세히 보기</em>
				</a></li>
				<li><a href="#">
					<strong>ACCESSORIES</strong>
					<em>자세히 보기</em>
				</a></li>
			</ul>
			</div>
			<div class="the-classics">
			<a href="#">
			<strong>THE CLASSICS</strong>
			<em>시그니쳐 아이템 쇼핑하러 가기</em>
			</a>
			</div>
			<div class="sns1">
			<ul class="cf">
				<li>
				<span>2016-12-12</span>
				<img src="images/sns1.jpg" alt="페이스북 최신 컨텐츠" />
				<p><a href="#">Stylist Jessica Zamora-Turner’s<br/> 7 Holiday Style Tips</a></p>
				</li>
				<li>
				<span>2016-12-10</span>
				<img src="images/sns2.jpg" alt="인스타그램 최신 컨텐츠" />
				
				</li>
			</ul>
			</div>
			<video src="images/video.mp4" > <!-- controls autoplay -->  </video>
			<div class="row-contents">
			<ul>
			<li>
			<strong>STORE LOCATION</strong>
			<form>
			<fieldset>
			<legend class="hide">매장찾기 폼</legend>
			<label for="search"></label>
			<input type="text"  id="search" class="text"/>
			<label for="searchSbumit"></label>
			<input type="image"  id="searchSbumit" src="images/search.png" width="35px"  class="submit"/>
			</fieldset>
			</form>
			</li>
			<li>
			<strong>NEWS LETTER</strong>
			<form>
			<fieldset>
			<legend class="hide">이메일 수집 폼</legend>
			<label for="email"></label>
			<input type="text"  id="email" class="text"/>
			<label for="emailSbumit"></label>
			<input type="image"  id="emailSbumit" src="images/search.png"  width="35px" class="submit"/>
			</fieldset>
			</form>
			</li>
			</ul>
			</div>
			
			<div class="sns2">
			<ul>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
			</ul>
			</div>
		</section>
	</div>

</div><!--////////////////////////////// visual-content-wrap-->

<div class="footer-wrap">
	<footer id="footer">
	<dl class="cf">
		<dt class="hide">footer-menu</dt>
		<dd><a href="#">사이트맵</a></dd>
		<dd><a href="#">GLOBAL SHIPPING</a></dd>
		<dd><a href="#">선물 포장 서비스 안내</a></dd>
		<dd><a href="#">고객센터</a></dd>
		<dd><a href="#">이용안내</a></dd>
		<dd><a href="#">개인정보 처리 방침</a></dd>
		<dd><a href="#">이메일 무단 수집 거부</a></dd>
	</dl>
	<address>삼성물산 패션 서울특별시 강남구 도곡동 467-12 대표 최치훈</address>
	<p>사업자 등록번호 101-85-43600<br/>통신판매업 신고번호 제 2015-서울강남-02894 </p>
	<span>고객센터 : 1599-9679 FAX : 02-2266-1202</span>
	</footer>
</div><!--////////////////////////////// footer-wrap-->

  <script type="text/javascript" src="js/jquery.js"> </script>
  <script type="text/javascript" src="js/jquery-ui.min.js"> </script>   
  <script type="text/javascript" src="js/prefixfree.js"> </script>
  <script type="text/javascript" src="js/common.js"> </script>
  <script type="text/javascript" src="js/main.js"> </script>

 </body>
</html>






















 
