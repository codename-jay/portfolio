$(function(){
	init();
})//endfunction

function init() {

 mainVisual(); 
 allMenu();
}
function mainVisual(){}

function allMenu(){
	
	$('.all-open').on('click',function(){
		$('#allMenu').fadeIn()
	})
	
	$('#allMenu .close').on('click',function(){
		$('#allMenu').fadeOut()
	})
	
	$('#allMenu .gnb li').on('click',function(){
		$('#allMenu').fadeOut()
	})
}

