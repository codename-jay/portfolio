$(function(){
	init();
})//endfunction

function init() {
 gnb();
 topScroll(); 
}
function gnb(){}
function topScroll(){}
